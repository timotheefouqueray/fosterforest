Please, note the following :

 - This is a packaged version of Cormas for the Model FosterForest_III

 - The Photo and Video tools require to have QuickTime installed on your computer
